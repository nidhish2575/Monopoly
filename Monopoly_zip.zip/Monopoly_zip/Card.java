package Monopoly.java;

public class Card {

    String name;

    Card(String name){

            this.name = name;

    }
   
}
