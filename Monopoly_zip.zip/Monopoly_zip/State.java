package Monopoly.java;

public class State {
	
	static int game_turn =0;

}
